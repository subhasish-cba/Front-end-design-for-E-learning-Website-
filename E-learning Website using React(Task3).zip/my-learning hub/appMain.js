const HeroSection = () => {
    return (
      <section className="header-content">
        <h1>Welcome to My Learning Hub</h1>
        <p>Your journey to knowledge starts here. Choose from our expertly curated courses and learn at your own pace!</p>
      </section>
    );
  };
  
  // Course component with a new structure, distinct naming, and hover effects
  const CourseCard = ({ title, description }) => {
    return (
      <div className="col-md-4">
        <div className="course-box">
          <h3 className="card-title">{title}</h3>
          <p className="card-text">{description}</p>
          <a href="#" className="btn btn-primary-custom">Enroll Now</a>
        </div>
      </div>
    );
  };
  
  // Function to load multiple courses
  const CourseList = () => {
    const courses = [
      { title: "Mastering HTML & CSS", description: "Learn the building blocks of web development." },
      { title: "JavaScript for Beginners", description: "Understand the basics of JavaScript and start coding." },
      { title: "React Development", description: "Get hands-on with React and build dynamic UIs." }
    ];
  
    return (
      <div className="container course-container">
        <div className="row">
          {courses.map((course, index) => (
            <CourseCard key={index} title={course.title} description={course.description} />
          ))}
        </div>
      </div>
    );
  };
  
  // Main application
  const App = () => {
    return (
      <div>
        <nav className="navbar navbar-expand-lg nav-custom">
          <a className="navbar-brand text-white" href="#">My Learning Hub</a>
          <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <a className="nav-link" href="#">Home</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#">Courses</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#">About Us</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#">Contact</a>
              </li>
            </ul>
          </div>
        </nav>
  
        <HeroSection />
        <CourseList />
  
        <footer>
          <p>&copy; 2024 My Learning Hub. All Rights Reserved.</p>
        </footer>
      </div>
    );
  };
  
  ReactDOM.render(<App />, document.getElementById("app-root"));
  